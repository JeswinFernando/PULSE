# PULSE — deploy instructions

Same drill as ARIVAN: this needs to run on Netlify (or any host with serverless
functions), not opened as a local file, because the two functions in
`netlify/functions/` are what let the browser talk to NVD and CISA without
hitting CORS.

## Deploy

1. Push this folder to a GitHub repo (or drag-and-drop the folder into
   Netlify's manual deploy screen at app.netlify.com).
2. If deploying via Git: in Netlify, "Add new site" → connect the repo.
   Build command: leave blank. Publish directory: `.` (root).
3. Netlify auto-detects `netlify/functions/` and deploys `nvd-proxy` and
   `kev-proxy` as serverless functions — no extra config needed, no API
   keys required.
4. Once deployed, open the site URL. Every fetch now goes to
   `/.netlify/functions/nvd-proxy` and `/.netlify/functions/kev-proxy`,
   which fetch NVD/CISA server-side and hand the JSON back to your browser.

## Notes

- Device inventory and last scan results are saved in the browser's
  `localStorage`, scoped to that site's domain. Different browser or
  incognito window = starts fresh.
- No secrets or API keys involved — NVD and CISA KEV are both public,
  unauthenticated feeds. The proxy exists purely to route around
  browser-side CORS, not for auth.
- If you ever want this to auto-refresh daily rather than on manual click,
  a Netlify scheduled function (`netlify/functions/daily-scan.js` on a cron
  trigger) could run the same logic and email/Slack you a digest — happy to
  build that next if useful.
